from ctypes import _CFuncPtr
from ctypes import _Pointer

_CFuncPtr.argtypes
_CFuncPtr.errcheck
_CFuncPtr.restype

_Pointer.contents

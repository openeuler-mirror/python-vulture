import sys

sys.excepthook

# Never report redirected streams as unused.
sys.stderr
sys.stdin
sys.stdout
